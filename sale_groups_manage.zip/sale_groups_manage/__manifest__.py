# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


{
    'name': 'Sales Groups',
    'author': 'Adarsh',
    'sequence': -100,
    'version': '1.0.0',
    'category': 'practice',
    'summary': 'Sales management system',
    'description': """Sales management system software""",
    'depends': ['hr', 'account', 'sale', ],
    'data': [
             'security/ir.model.access.csv',
             'security/security.xml',
             # 'views/menu.xml',
             # 'views/odoo_practise.xml',
             'views/p_tags.xml',
             'views/field_visible.xml',
             ],
    'demo': [],
    'installable': True,
    'application': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
