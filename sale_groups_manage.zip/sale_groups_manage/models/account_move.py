from odoo import api, fields, models, _
from odoo.exceptions import UserError


class AccountMoveInherit(models.Model):
    _inherit = "account.move"

    manager_remarks = fields.Text(string="Manager Remarks",
                                  )
    director_remarks = fields.Text(string="Director Remarks",
                                   )
    default = fields.Boolean(string='default', compute='default_check')
    group_1 = fields.Boolean(string='group_1', compute='default_check')
    group_2 = fields.Boolean(string='group_2', compute='default_check')

    # @api.constrains('manager_remarks', 'director_remarks')
    # def remark_actions(self):
    #     for record in self:
    #         if record.state == 'draft' and (record.manager_remarks or not record.director_remarks):
    #             raise UserError(_('Please fill Remarks before posting the invoice.'))

    def action_post(self):
        if not self.move_type == 'in_invoice':
            for record in self:
                if record.manager_remarks and record.director_remarks:
                    record.state = 'posted'
                else:
                    raise UserError(_('Please fill Remarks before posting the invoice.'))
        else:
            self.state = 'posted'

    @api.depends('user_id')
    def default_check(self):
        if self.env.user.has_group('sale_groups_manage.sales_custom_manager') and self.env.user.has_group(
                'sale_groups_manage.sales_custom_director'):
            self.default = True
        else:
            self.default = False
        if self.env.user.has_group('sale_groups_manage.sales_custom_manager'):
            self.group_1 = True
            self.default = True
        else:
            self.group_1 = False
        if self.env.user.has_group('sale_groups_manage.sales_custom_director'):
            self.group_2 = True
            self.default = True
        else:
            self.group_2 = False
            # print(self.default)


